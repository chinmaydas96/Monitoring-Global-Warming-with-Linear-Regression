* Anaconda installation Tutorial : 

https://medium.com/@neuralnets/beginners-quick-guide-for-handling-issues-launching-jupyter-notebook-for-python-using-anaconda-8be3d57a209b

* Basic Jupyter-notebook Tutorial :

https://github.com/fastai/course-v3/blob/master/nbs/dl1/00_notebook_tutorial.ipynb

https://www.dataquest.io/blog/jupyter-notebook-tutorial/

* Basic Python Tutorial :

https://data36.com/python-for-data-science-python-basics-1/

* Basic Pandas, numpy and matplotlib Tutorial :

https://cloudxlab.com/blog/numpy-pandas-introduction/

https://data36.com/pandas-tutorial-1-basics-reading-data-files-dataframes-data-selection/


* Machin Learning for Highschool student :

https://github.com/kjaisingh/high-school-guide-to-machine-learning
